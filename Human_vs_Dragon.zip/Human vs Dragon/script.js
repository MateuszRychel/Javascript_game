// HP hero
let hero_health_element = document.getElementById('hp_hero');
let hero_health = 100;
hero_health_element.innerText = hero_health;


function enemy() {
    hero_health = hero_health - 20;
    hero_health_element.innerText = hero_health;
}


const credits = ` 
                  Dziękuje za grę
                  

                  Spróbuj następnym razem a napewno się uda
                  

                  Tytuł: Human vs Dragon
                  

                  Twórca: Mati
                  

                  Twórca napisów: Mati
                  

                  Twórca wizualny: Mati
                  

                  Pomoc techniczna: Konrad


                  Muzyka: żadna
                  

                  Koniec     
`;;


const credits2 = ` 
                   Dziękuje za ukończenie gry
                   

                   Tytuł: Human vs Dragon
                   

                   Twórca: Mati
                   

                   Tytuł: Human vs Dragon
                   

                   Twórca: Mati
                   

                   Twórca napisów: Mati
                   

                   Twórca wizualny: Mati
                   

                   Pomoc techniczna: Konrad


                   Muzyka: żadna


                   Koniec
`;;


function turn() {
    if(hero_health <= 0) {
        console.log("dead");
        document.querySelector(".grid-container-element").style.visibility="hidden";
        document.querySelector(".grid-container-element2").style.visibility="hidden";
        document.getElementById("1").remove();
        document.getElementById("2").remove();
        const dupa = document.querySelector(".div2");
        document.getElementById('div2-content').innerText = credits;
        dupa.classList.remove("div2");
        dupa.classList.add("div2");
    }
    

    if(dragon_health <=0) {
        console.log("smok zginał");
        document.querySelector(".grid-container-element").style.visibility="hidden";
        document.querySelector(".grid-container-element2").style.visibility="hidden";
        document.getElementById("1").remove();
        document.getElementById("2").remove();
        const dupa = document.querySelector(".div2");
        document.getElementById('div2-content').innerText = credits2;
        dupa.classList.remove("div2");
        dupa.classList.add("div2");
    }
}


// HP Dragon
let dragon_health_element = document.getElementById('hp_dragon');
let dragon_health = 1000;
dragon_health_element.innerText = dragon_health;



// Timer (Git)
    let zegar = document.getElementById('time');
    let ticker = 40;
    const interval = setInterval(() => {
        if(ticker == 0)   {
            clearInterval(interval);
            location.reload();
        } 
        zegar.innerHTML = (ticker + " sek");
        ticker--;
    }, 1000);


// Ilość apteczek (Git)
    let apteczki = 4;
    let count_fak_element = document.getElementById("count_fak");
    count_fak_element.innerText = apteczki;
    let button = document.getElementById('weapon_fak');
    button.addEventListener('click', () => {
        apteczki = apteczki -1;
        hero_health = hero_health + 40;
        hero_health_element.innerText = hero_health;
        if (apteczki == 0) {
            button.disabled = true;
        }
        count_fak_element.innerText = apteczki;
        enemy();
        turn();
    });


// Fireball
    let button3 = document.getElementById('weapon_fireball'); 
    button3.addEventListener('click', () => {
        dragon_health = dragon_health - 400;
        dragon_health_element.innerText = dragon_health;
        enemy();
        turn();
    });


// Axe
    let button4 = document.getElementById('weapon_axe');
    button4.addEventListener('click', () => {
        dragon_health = dragon_health - 150;
        dragon_health_element.innerText = dragon_health;
        enemy();
        turn();
    });


// Bow
    let button5 = document.getElementById('weapon_bow'); 
    button5.addEventListener('click', () => {
        dragon_health = dragon_health - 50;
        dragon_health_element.innerText = dragon_health;
        enemy();
        turn();
    });  